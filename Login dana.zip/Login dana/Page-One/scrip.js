// Inisialisasi Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBYDkKNob6mSMD26kPXU9f7ZygmAGYzDpI",
  authDomain: "login-dana.firebaseapp.com",
  databaseURL: "https://login-dana-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "login-dana",
  storageBucket: "login-dana.appspot.com",
  messagingSenderId: "574482619975",
  appId: "1:574482619975:web:ea48052f15ccf21ae1db62",
  measurementId: "G-TPR0NWV5CT"
};

const app = firebase.initializeApp(firebaseConfig);

