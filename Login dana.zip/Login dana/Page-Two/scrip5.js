const firebaseConfig = {
  apiKey: "AIzaSyCbtzN8xO8uXhoLMyx8JlU3xPzO5aDCAtQ",
  authDomain: "login-dana-2.firebaseapp.com",
  databaseURL: "https://login-dana-2-default-rtdb.firebaseio.com",
  projectId: "login-dana-2",
  storageBucket: "login-dana-2.appspot.com",
  messagingSenderId: "63426208161",
  appId: "1:63426208161:web:d4f0b1af7d8e64bed7ebe0"
};
const app = firebase.initializeApp(firebaseConfig);

